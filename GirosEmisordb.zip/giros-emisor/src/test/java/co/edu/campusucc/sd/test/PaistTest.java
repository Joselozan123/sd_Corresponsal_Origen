package co.edu.campusucc.sd.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import co.edu.campusucc.sd.daos.PaisDAO;
import co.edu.campusucc.sd.modelo.Pais;

class PaistTest {

	@Test
	void testPersist() {
		PaisDAO dao = new PaisDAO();
		Pais o = new Pais();

		o.setGentilicioNacional("42");
		o.setIdPais("75");
		o.setNombre("85");
		
		try {
			dao.persist(o);
			assertTrue(true);

		} catch (Exception e) {

			fail(e.toString());
		}
	}
}
