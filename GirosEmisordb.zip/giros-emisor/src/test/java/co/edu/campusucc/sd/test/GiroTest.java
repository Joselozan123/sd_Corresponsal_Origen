package co.edu.campusucc.sd.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import co.edu.campusucc.sd.daos.GiroDAO;
import co.edu.campusucc.sd.modelo.Giro;

class GiroTest {

	@Test
	void testPersist() {
		GiroDAO dao = new GiroDAO();
		Giro o = new Giro();

		o.setIdGiro("27");
		o.setIdPais("87");
		o.setFechaGiro("agosto/23/2020");

		try {
			dao.persist(o);
			assertTrue(true);

		} catch (Exception e) {

			fail(e.toString());
		}
	}

}
