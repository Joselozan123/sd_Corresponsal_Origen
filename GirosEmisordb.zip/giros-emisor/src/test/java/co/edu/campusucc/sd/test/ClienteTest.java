package co.edu.campusucc.sd.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import co.edu.campusucc.sd.daos.ClienteDAO;
import co.edu.campusucc.sd.modelo.Cliente;


class ClienteTest {

	@Test
	void testPersist() {
		ClienteDAO dao = new ClienteDAO();
		Cliente o = new Cliente();
		

		o.setIdCliente("432");
		o.setNombres("Macacio");
		o.setApellidos("Sterling");
		o.setRazonSocial("Empresa");
		o.setIdDestinatario("422");
		o.setIdGiro("654");
		

		try {
			dao.persist(o);
			assertTrue(true);

		} catch (Exception e) {

			fail(e.toString());
		}
	}

}
